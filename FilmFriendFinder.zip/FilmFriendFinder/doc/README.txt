# FilmFriendFinder
Luke Munro, Randall Williams, Ahmed Osman, Thanh (Jason), Keir Charlton-Molloy

Start the website by running the HomePage.jsp file on a Tomcat server and then you can navigate to the other pages using the navbar or clicking on the appropriate options. 

Multi-threading can be performed by running the SendNotification.java file and then opening two different pages. Creating a project on one of the pages should result in a notification appearing on the other page after a couple seconds. 
